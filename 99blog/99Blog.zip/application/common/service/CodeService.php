<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/5
 * Time: 23:57
 */

namespace app\common\service;

/**
 * 验证码服务类
 * Class CodeService
 * @package app\common\service
 */
class CodeService {


    public static function validate() {

    }
}