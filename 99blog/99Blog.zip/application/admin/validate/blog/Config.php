<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/11
 * Time: 23:10
 */

namespace app\admin\validate\blog;


use think\Validate;

/**
 * 博客配置验证器
 * Class Config
 * @package app\admin\validate\blog
 */
class Config extends Validate {

}