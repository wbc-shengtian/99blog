<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/11
 * Time: 1:29
 */

namespace app\admin\service;

/**
 * 文章服务类
 * Class ArticleService
 * @package app\admin\service
 */
class ArticleService {

}